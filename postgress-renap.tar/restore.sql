--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Debian 10.7-1.pgdg90+1)
-- Dumped by pg_dump version 15.8 (Debian 15.8-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE renap;
--
-- Name: renap; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE renap WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE renap OWNER TO postgres;

\connect renap

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: delete_person(); Type: FUNCTION; Schema: public; Owner: hook
--

CREATE FUNCTION public.delete_person() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN

    INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
    VALUES (OLD.dpi, '*DELETE*', NULL, NULL, 'DELETE', CURRENT_TIMESTAMP)
    ON CONFLICT (dpi, field)
    DO UPDATE SET
        operation_date = EXCLUDED.operation_date;
    RETURN OLD;

	END;
$$;


ALTER FUNCTION public.delete_person() OWNER TO hook;

--
-- Name: insert_person(); Type: FUNCTION; Schema: public; Owner: hook
--

CREATE FUNCTION public.insert_person() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
  INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
    VALUES (NEW.dpi, '*INSERT*', NULL, NULL, 'INSERT', CURRENT_TIMESTAMP)
    ON CONFLICT (dpi, field)
    DO UPDATE SET 
        old_value = EXCLUDED.old_value,
        new_value = EXCLUDED.new_value,
        operation_type = EXCLUDED.operation_type,
        operation_date = EXCLUDED.operation_date;
    RETURN NEW;
	END;
$$;


ALTER FUNCTION public.insert_person() OWNER TO hook;

--
-- Name: update_person(); Type: FUNCTION; Schema: public; Owner: hook
--

CREATE FUNCTION public.update_person() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
    IF OLD.first_name IS DISTINCT FROM NEW.first_name THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'first_name', OLD.first_name, NEW.first_name, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.second_name IS DISTINCT FROM NEW.second_name THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'second_name', OLD.second_name, NEW.second_name, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.first_surname IS DISTINCT FROM NEW.first_surname THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'first_surname', OLD.first_surname, NEW.first_surname, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.second_surname IS DISTINCT FROM NEW.second_surname THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'second_surname', OLD.second_surname, NEW.second_surname, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.home_address IS DISTINCT FROM NEW.home_address THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'home_address', OLD.home_address, NEW.home_address, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.home_phone IS DISTINCT FROM NEW.home_phone THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'home_phone', OLD.home_phone, NEW.home_phone, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.mobile_phone IS DISTINCT FROM NEW.mobile_phone THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'mobile_phone', OLD.mobile_phone, NEW.mobile_phone, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.base_salary IS DISTINCT FROM NEW.base_salary THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'base_salary', OLD.base_salary, NEW.base_salary, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    IF OLD.bonus IS DISTINCT FROM NEW.bonus THEN
        INSERT INTO transaction (dpi, field, old_value, new_value, operation_type, operation_date)
        VALUES (NEW.dpi, 'bonus', OLD.bonus, NEW.bonus, 'UPDATE', CURRENT_TIMESTAMP)
        ON CONFLICT (dpi, field)
        DO UPDATE SET 
            old_value = EXCLUDED.old_value,
            new_value = EXCLUDED.new_value,
            operation_type = EXCLUDED.operation_type,
            operation_date = EXCLUDED.operation_date;
    END IF;

    RETURN NEW;
	END;
$$;


ALTER FUNCTION public.update_person() OWNER TO hook;

SET default_tablespace = '';

--
-- Name: person; Type: TABLE; Schema: public; Owner: hook
--

CREATE TABLE public.person (
    dpi character varying(20) NOT NULL,
    first_name character varying(100),
    second_name character varying(100),
    first_surname character varying(100),
    second_surname character varying(100),
    home_address text,
    home_phone character varying(20),
    mobile_phone character varying(20),
    base_salary real,
    bonus real
);


ALTER TABLE public.person OWNER TO hook;

--
-- Name: transaction; Type: TABLE; Schema: public; Owner: hook
--

CREATE TABLE public.transaction (
    id integer NOT NULL,
    dpi character varying(20),
    field character varying(100),
    old_value text,
    new_value text,
    operation_type character varying(50),
    operation_date timestamp without time zone
);


ALTER TABLE public.transaction OWNER TO hook;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: hook
--

CREATE SEQUENCE public.transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_id_seq OWNER TO hook;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hook
--

ALTER SEQUENCE public.transaction_id_seq OWNED BY public.transaction.id;


--
-- Name: transaction id; Type: DEFAULT; Schema: public; Owner: hook
--

ALTER TABLE ONLY public.transaction ALTER COLUMN id SET DEFAULT nextval('public.transaction_id_seq'::regclass);


--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: hook
--

COPY public.person (dpi, first_name, second_name, first_surname, second_surname, home_address, home_phone, mobile_phone, base_salary, bonus) FROM stdin;
\.
COPY public.person (dpi, first_name, second_name, first_surname, second_surname, home_address, home_phone, mobile_phone, base_salary, bonus) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: hook
--

COPY public.transaction (id, dpi, field, old_value, new_value, operation_type, operation_date) FROM stdin;
\.
COPY public.transaction (id, dpi, field, old_value, new_value, operation_type, operation_date) FROM '$$PATH$$/2867.dat';

--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hook
--

SELECT pg_catalog.setval('public.transaction_id_seq', 68, true);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: hook
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (dpi);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: hook
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: transaction unique_dpi_field; Type: CONSTRAINT; Schema: public; Owner: hook
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT unique_dpi_field UNIQUE (dpi, field);


--
-- Name: person delete_person_after; Type: TRIGGER; Schema: public; Owner: hook
--

CREATE TRIGGER delete_person_after AFTER DELETE ON public.person FOR EACH ROW EXECUTE PROCEDURE public.delete_person();


--
-- Name: person insert_person_after; Type: TRIGGER; Schema: public; Owner: hook
--

CREATE TRIGGER insert_person_after AFTER INSERT ON public.person FOR EACH ROW EXECUTE PROCEDURE public.insert_person();


--
-- Name: person update_person_after; Type: TRIGGER; Schema: public; Owner: hook
--

CREATE TRIGGER update_person_after AFTER UPDATE ON public.person FOR EACH ROW EXECUTE PROCEDURE public.update_person();


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

